import { defineChannelPluginEntry } from "openclaw/plugin-sdk/channel-core";
import { maxPlugin, initializeBot } from "./src/channel.js";
import { Context } from "@maxhub/max-bot-api";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk/channel-core";

const entry: any = defineChannelPluginEntry({
  id: "max",
  name: "MAX Messenger",
  description: "MAX Messenger channel plugin for OpenClaw",
  plugin: maxPlugin,
  registerFull(api: OpenClawPluginApi) {
    // Initialize bot from config
    const token = api.pluginConfig?.token as string | undefined;
    if (token) {
      const bot = initializeBot(token);
      
      // Handle incoming messages
      bot.on('message_created', async (ctx: Context) => {
        const message = ctx.message;
        const user = ctx.user;
        
        // Register channel for inbound messages
        api.registerChannel({
          plugin: maxPlugin,
        });
      });
      
      // Start polling
      bot.start({ allowedUpdates: ['message_created'] });
    }
    
    // Register HTTP route for webhook (if needed)
    api.registerHttpRoute({
      path: "/max/webhook",
      auth: "plugin",
      handler: async (req, res) => {
        // Handle webhook if needed
        res.statusCode = 200;
        res.end("ok");
        return true;
      },
    });
  },
});

export default entry;
