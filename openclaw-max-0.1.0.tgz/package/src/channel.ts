import {
  createChatChannelPlugin,
} from "openclaw/plugin-sdk/channel-core";
import type { OpenClawConfig } from "openclaw/plugin-sdk/channel-core";
import { Bot } from "@maxhub/max-bot-api";

type ResolvedAccount = {
  accountId: string | null;
  token: string;
  allowFrom: string[];
  dmPolicy: string | undefined;
};

function resolveAccount(
  cfg: OpenClawConfig,
  accountId?: string | null,
): ResolvedAccount {
  const section = (cfg.channels as Record<string, any>)?.["max"];
  const token = section?.token;
  if (!token) throw new Error("max: token is required");
  return {
    accountId: accountId ?? null,
    token,
    allowFrom: section?.allowFrom ?? [],
    dmPolicy: section?.dmSecurity,
  };
}

// Store bot instance for outbound messaging
let botInstance: Bot | null = null;

export const maxPlugin = createChatChannelPlugin<ResolvedAccount>({
  base: {
    id: "max",
    meta: {
      id: "max",
      label: "MAX Messenger",
      selectionLabel: "MAX Messenger (Bot API)",
      detailLabel: "MAX Messenger Bot",
      docsPath: "/channels/max",
      docsLabel: "max",
      blurb: "Connect OpenClaw to MAX messenger.",
      systemImage: "message",
    },
    capabilities: {
      chatTypes: ["direct"],
    },
    setup: {
      resolveAccountId: (params: any) => {
        const section = params.cfg?.channels?.["max"];
        return section?.token ? "max-account" : "";
      },
      applyAccountConfig: (params: any) => {
        // Return config as-is for now
        return params.cfg;
      },
    },
    config: {
      listAccountIds: (cfg: any) => {
        const section = cfg?.channels?.["max"];
        return section?.token ? ["max-account"] : [];
      },
      resolveAccount: (cfg: any, accountId?: string | null) => {
        return resolveAccount(cfg, accountId);
      },
    },
  },

  // DM security: who can message the bot
  security: {
    dm: {
      channelKey: "max",
      resolvePolicy: (account) => account.dmPolicy,
      resolveAllowFrom: (account) => account.allowFrom,
      defaultPolicy: "allowlist",
    },
  },

  // Pairing: approval flow for new DM contacts
  pairing: {
    text: {
      idLabel: "MAX user ID",
      message: "Send this code to verify your identity:",
      notify: async (params: any) => {
        if (botInstance) {
          await botInstance.api.sendMessageToUser(Number(params.id), `Pairing code: ${params.code}`);
        }
      },
    },
  },

  // Threading: how replies are delivered
  threading: { topLevelReplyToMode: "reply" },

  // Outbound: send messages to the platform
  outbound: {
    deliveryMode: "direct",
    sendText: async (params: any) => {
      if (!botInstance) {
        throw new Error("MAX bot not initialized");
      }
      await botInstance.api.sendMessageToUser(
        Number(params.to),
        params.text,
      );
      return { channel: "max", messageId: String(Date.now()) };
    },
  },
});

// Initialize bot function
export function initializeBot(token: string): Bot {
  botInstance = new Bot(token);
  return botInstance;
}

// Get current bot instance
export function getBot(): Bot | null {
  return botInstance;
}
