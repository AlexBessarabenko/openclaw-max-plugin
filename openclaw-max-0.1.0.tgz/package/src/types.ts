export interface OpenClawPlugin {
  id: string;
  name: string;
  version: string;
  description: string;
  init(runtime: OpenClawRuntime): Promise<void>;
  destroy?(): Promise<void>;
}

export interface OpenClawRuntime {
  registerChannel(id: string, channel: new (...args: any[]) => Channel): void;
  registerTool(name: string, handler: Function): void;
}

export interface Channel {
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  send(message: OutboundMessage): Promise<void>;
  onMessage(handler: (message: InboundMessage) => Promise<void>): void;
}

export interface ChannelConfig {
  id: string;
  [key: string]: any;
}

export interface InboundMessage {
  id: string;
  text: string;
  user: {
    id: string;
    name: string;
  };
  channel: string;
  timestamp: Date;
  raw: any;
}

export interface OutboundMessage {
  target: string;
  text: string;
  channel: string;
  [key: string]: any;
}
