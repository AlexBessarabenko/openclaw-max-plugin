import { Bot, Context } from '@maxhub/max-bot-api';

export interface MaxPluginConfig {
  token: string;
  allowFrom?: string[];
}

export class MaxPlugin {
  private bot?: Bot;
  private config: MaxPluginConfig;
  private messageHandler?: (message: any) => Promise<void>;

  constructor(config: MaxPluginConfig) {
    this.config = config;
  }

  async start(): Promise<void> {
    this.bot = new Bot(this.config.token);
    
    // Handle incoming messages
    this.bot.on('message_created', async (ctx: Context) => {
      if (this.messageHandler) {
        const message = ctx.message;
        const user = ctx.user;
        
        await this.messageHandler({
          id: ctx.messageId || '',
          text: message?.body.text || '',
          user: {
            id: String(user?.user_id || ''),
            name: user?.name || 'Unknown',
          },
          channel: 'max',
          timestamp: new Date(message?.timestamp || Date.now()),
          raw: ctx.update,
        });
      }
    });

    // Start polling
    await this.bot.start({
      allowedUpdates: ['message_created'],
    });
  }

  async stop(): Promise<void> {
    this.bot?.stop();
  }

  async sendMessage(userId: string, text: string): Promise<void> {
    if (!this.bot) {
      throw new Error('Bot not started');
    }

    const id = Number(userId);
    if (isNaN(id)) {
      throw new Error('Invalid user ID');
    }

    await this.bot.api.sendMessageToUser(id, text);
  }

  onMessage(handler: (message: any) => Promise<void>): void {
    this.messageHandler = handler;
  }
}

export default MaxPlugin;
