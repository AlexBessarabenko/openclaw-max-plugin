import { defineSetupPluginEntry } from "openclaw/plugin-sdk/channel-core";
import { maxPlugin } from "./src/channel.js";

export default defineSetupPluginEntry(maxPlugin);
